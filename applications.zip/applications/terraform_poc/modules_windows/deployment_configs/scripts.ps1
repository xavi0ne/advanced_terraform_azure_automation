Connect-AzAccount -Environment AzureUSGovernment

$clientId = "f2967eb3-17f1-435c-b169-395d413d3e49"
$subscriptionId = "b17355c5-5949-49ef-a5e8-a69a19f06126"
$tenantId = "7710f39e-a5ca-49b0-8bf7-3ffdb30e3ab1"



$appName = "Fabrikam"

$varFile = './deployment_configs/deploy.tfvars'

$env:ARM_CLIENT_ID = $clientId
$env:ARM_SUBSCRIPTION_ID = $subscriptionId
$env:ARM_TENANT_ID = $tenantId
$env:APP_NAME = $appName


$storageResourceGroup = "Devops"
$storageName = "devstore1"
$storageKey = (Get-AzStorageAccountKey -ResourceGroupName $storageResourceGroup -Name $storageName).Value[0]
$env:ARM_ACCESS_KEY = $storageKey

terraform init -var-file=$varFile -backend-config="key=$($env:APP_NAME).tfstate"

terraform plan -var-file=$varFile

terraform refresh -var-file=$varFile

terraform apply -var-file=$varFile -auto-approve

#skip_provider_registration = true